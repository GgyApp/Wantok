import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  // Load env file based on `mode` in the current working directory.
  // Set the third parameter to '' to load all env regardless of the `VITE_` prefix.
  const env = loadEnv(mode, '.', '');
  
  // Prioritize system process.env (for Cloudflare Pages/CI) over local .env file
  // This ensures that when you run `npm run build`, the API key is injected.
  const apiKey = process.env.API_KEY || env.API_KEY;

  return {
    plugins: [react()],
    base: '/',
    define: {
      // JSON.stringify is required here as the define plugin does a literal replacement
      'process.env.API_KEY': JSON.stringify(apiKey)
    },
    build: {
      outDir: 'dist',
      sourcemap: false
    }
  }
})